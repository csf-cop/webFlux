/**
 * 
 */
package com.csf.whoami.security;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author TuanDQ
 *
 */
@RestController
@RequestMapping("/auth")
public class AuthenticationController {


    @Autowired
    private TokenProvider tokenProvider;

    @Autowired
    private UserService userService;

    @Value("${timeout-in-web}")
    private String timeOut;

    /**
     * @param loginUser
     * @return
     * @throws Exception
     * @desctiption Controller login system for role user
     */
    @RequestMapping(value = "/user/login", method = RequestMethod.POST)
    public ResponseEntity<Object> login(@Valid @RequestBody LoginUser loginUser) throws Exception {
        Object result;

        final Authentication authentication = authenticationManager.authenticate(
                new CustomAuthenticationClinicToken(loginUser.getLoginId(), loginUser.getPassword(), null));
        SecurityContextHolder.getContext().setAuthentication(authentication);

        final String token = tokenProvider.generateToken(authentication, null);
        final String refreshToken = tokenProvider.generateRefeshToken(authentication, null);

        UserDTO userDTO = (UserDTO) authentication.getPrincipal();


        UserDTOWithNetworks loginSuccessUser;

        List<RoleDTO> listRole = userDTO.getRoles();
        if(listRole == null || listRole.size() == 0) {
            throw new AccessDeniedException("Access Denied");
        }

        if(listRole.get(0).getCode().equals(UserRoles.SYSTEM_ADMIN.getValue()) || listRole.get(0).getCode().equals(UserRoles.INPUT_PERSON.getValue()) || listRole.get(0).getCode().equals(UserRoles.MAMA_KELLY.getValue())) {
            loginSuccessUser = userService.getUser(loginUser.getLoginId());
        } else {
            throw new AccessDeniedException("Access Denied");
        }
        result = new LoginResponseWithNetworks(loginSuccessUser, token, refreshToken);
        ((LoginResponseWithNetworks) result).setTimeOut(timeOut);
        ResponseDataAPI responseDataAPI = new ResponseDataAPI();
        responseDataAPI.setSuccess(true);
        responseDataAPI.setData(result);
        return new ResponseEntity<>(responseDataAPI, HttpStatus.OK);
    }
}
