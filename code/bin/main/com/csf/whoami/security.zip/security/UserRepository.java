/**
 * 
 */
package com.csf.whoami.security;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author TuanDQ
 *
 */
@Repository
public interface UserRepository extends JpaRepository<UserEntity, Long> {

	UserEntity findByLoginIdAndIsDeleted(String loginId, Integer valueOf);
}
