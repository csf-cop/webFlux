/**
 * 
 */
package com.csf.whoami.security;

import java.io.Serializable;

/**
 * @author TuanDQ
 *
 */
public class BaseEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
