package com.csf.whoami.security;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service(value = "userService")
@Transactional
public class UserServiceImpl implements UserService, UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDTO getUserById(Long id) {
		Optional<UserEntity> optional = userRepository.findById(id);
		if (!optional.isPresent()) {
			return null;
		}
		return optional.get().convertToDTO();
	}

	@Override
	public UserDTO getUserByLoginId(String loginId) {
		UserEntity user = userRepository.findByLoginIdAndIsDeleted(loginId, Integer.valueOf("0"));
		return user != null ? user.convertToDTO() : null;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}
}
