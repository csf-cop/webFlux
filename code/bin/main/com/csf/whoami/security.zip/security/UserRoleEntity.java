/**
 * 
 */
package com.csf.whoami.security;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Where;

/**
 * @author TuanDQ
 *
 */
@Entity
@Table(name = "S03DT_USER_ROLE")
@Where(clause="is_deleted = 0")
public class UserRoleEntity extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
	@SequenceGenerator(name = "S03DT_USER_ROLE_SEQ", sequenceName = "S03DT_USER_ROLE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy= GenerationType.AUTO,  generator = "S03DT_USER_ROLE_SEQ")
	private Long id;

	@ManyToOne(optional = false)
	@JoinColumn(name = "USER_ID", foreignKey = @ForeignKey(name = "FK_S01DT_USER1"))
	private UserEntity user;

	@ManyToOne(optional = false)
	@JoinColumn(name = "ROLE_ID", foreignKey = @ForeignKey(name = "FK_S02ST_ROLE1"))
	private RoleEntity role;

	public UserRoleEntity() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the user
	 */
	public UserEntity getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(UserEntity user) {
		this.user = user;
	}

	/**
	 * @return the role
	 */
	public RoleEntity getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(RoleEntity role) {
		this.role = role;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}