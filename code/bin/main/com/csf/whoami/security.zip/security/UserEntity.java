/**
 * 
 */
package com.csf.whoami.security;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Where;

/**
 * @author TuanDQ
 *
 */
@Entity
@Table(name = "TBL_USERS")
@Where(clause = "is_deleted = 0")
public class UserEntity extends BaseEntity {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "LOGIN_ID", length = 10)
	private String loginId;

	@Column(name = "PASSWORD", length = 100)
	private String password;

	@Column(name = "FULL_NAME", length = 30)
	private String fullName;

	@Column(name = "PHONE", length = 20)
	private String phone;

	@Column(name = "FULL_ADDRESS", length = 60)
	private String fullAddress;

	@Column(name = "EMAIL", length = 80)
	private String email;

	@Column(name = "IS_DELETED", columnDefinition = "Numeric(2,0) default '0'")
	private Integer isDeleted;

	@OneToMany(mappedBy = "user")
    private List<UserRoleEntity> userRoles;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the loginId
	 */
	public String getLoginId() {
		return loginId;
	}

	/**
	 * @param loginId the loginId to set
	 */
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}

	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * @return the fullAddress
	 */
	public String getFullAddress() {
		return fullAddress;
	}

	/**
	 * @param fullAddress the fullAddress to set
	 */
	public void setFullAddress(String fullAddress) {
		this.fullAddress = fullAddress;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the isDeleted
	 */
	public Integer getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted the isDeleted to set
	 */
	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
     * @return
     * @desctiption Convert Entity to DTO
     */
    public UserDTO convertToDTO() {
		UserDTO userDTO = new UserDTO(this.loginId, this.fullName, String.valueOf(this.id), null);
        if (this.userRoles != null) {
            userDTO.setRoles(this.userRoles.stream().map(us -> us.getRole().convertDTO()).collect(Collectors.toList()));
        }
        userDTO.setPassword(this.password);
        return userDTO;
    }

}