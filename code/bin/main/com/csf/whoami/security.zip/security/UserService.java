package com.csf.whoami.security;

public interface UserService {

    UserDTO getUserById(Long id);

    UserDTO getUserByLoginId(String loginId);
}
